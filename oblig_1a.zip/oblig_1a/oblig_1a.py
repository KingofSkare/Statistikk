###   Set-Up   ###
# Packages
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.lines import Line2D
import os


# Example using seaborn color palette
colors = sns.color_palette('pastel')


# Functions
def find_median(df, column):
   # Find the amount of data points.
   n = len(df[column]) # Get length of column

   # Check if "n" is a odd or even number
   if n % 2 == 0:
     # "n" is even
     median = (1/2) * ( df.at[(n / 2), column] + df.at[((n + 2) / 2), column]) # df.at[i, column] gets value at index i of the column.
   else:
     # "n" is odd
     median = df.at[((n + 1) / 2), column]
   
   return median

def count_unique_values(df, column_name, unique_values_colum_name, count_name):
    # Find unique values and their counts
    unique_values_counts = df[column_name].value_counts()

    # Create a new DataFrame with unique values and counts
    result_df = pd.DataFrame({
        unique_values_colum_name: unique_values_counts.index,
        count_name: unique_values_counts.values
    })

    return result_df

def get_largest_value(df, unique_values_colum_name, count_name):
    # Find the index of the largest count
    max_count_index = df[count_name].idxmax()
    # Locate value with the corresponding index
    mode = df.loc[max_count_index, unique_values_colum_name]

    return mode
     

# Define data set class
class data_set:
  def __init__(self):
    self.path = None
    self.df_raw = None
    self.df_unique = None
    self.df_rising = None
    self.mode = None
    self.median = None
    self.n = None
    self.sum = None
    self.avg = None
    self.freq = None
    self.cum_freq = None
    self.std = None
    self.std_pop = None




# Initialize classes and import data
# FriFiskerForening (4F)
FriFiskerForening = data_set()
FriFiskerForening.path = "oblig_1a/data/FriFiskerForening.xlsx"
FriFiskerForening.df_raw = pd.read_excel(FriFiskerForening.path)

# Laban
laban = data_set()
laban.path = "oblig_1a/data/Laban42.xlsx"
laban.df_raw = pd.read_excel(laban.path)

# Brynhild
brynhild = data_set()
brynhild.path = "oblig_1a/data/Brynhild42.xlsx"
brynhild.df_raw = pd.read_excel(brynhild.path)



####    Task 1    ####
###   Task 1b   ###
##  Import data  ##
# Engineer Class income
print("Engineering class income")
engineer_income = data_set()
engineer_income.path = "oblig_1a/data/ingeniør_inntekter.xlsx"
engineer_income.df_raw = pd.read_excel(engineer_income.path)
print("-------------------------------------------")
print(engineer_income.df_raw)
print("-------------------------------------------")


##  Find mode value  ##
# Create dataframe with unique value
engineer_income.df_unique = count_unique_values(engineer_income.df_raw, "Inntekt", "Unique_Values", "Counts")

# Locate mode value
mode_b_man = get_largest_value(engineer_income.df_unique, "Unique_Values", "Counts")

# Alternativly, you can use this function from Pandas:
engineer_income.mode = engineer_income.df_raw["Inntekt"].mode().iloc[0]

# Print out results
print(f"The mode is {mode_b_man}, found manually.")
print(f"The mode is {engineer_income.mode}, according to Panda.")


## Find median value ##
# Sort data in ascending order
engineer_income.df_rising = engineer_income.df_raw.sort_values(by='Inntekt', ascending=True) 

# Locate median
median_b_man = find_median(engineer_income.df_rising, "Inntekt")

# Alternativly, you can use this function from Pandas:
engineer_income.median = engineer_income.df_raw['Inntekt'].median()

# Print out results
print(f"The median is {median_b_man}, found manually.")
print(f"The median is {engineer_income.median}, according to Panda.")


## Find average value  ##
# Find the number of elements
engineer_income.n = len(engineer_income.df_raw["Inntekt"])

# Find sum of elements
engineer_income.sum = engineer_income.df_raw["Inntekt"].sum()

# Find mean value
avg_b_man = engineer_income.sum / engineer_income.n

# Alternativly, you can use this function from Pandas:
engineer_income.avg = engineer_income.df_raw["Inntekt"].mean()

# Print out results
print(f"The average is {avg_b_man}, found manually.")
print(f"The average is {engineer_income.avg}, according to Panda.")
print("")
print("")




###   Task 1c   ###
# Import data
# Class income
print("Class income")
class_income = data_set()
class_income.path = "oblig_1a/data/klasse_inntekter.xlsx"
class_income.df_raw = pd.read_excel(class_income.path)
print("-------------------------------------------")
print(class_income.df_raw)
print("-------------------------------------------")

# Mode
class_income.mode = class_income.df_raw["Inntekt"].mode().iloc[0]

# Median
class_income.median = class_income.df_raw['Inntekt'].median()

# Mean
class_income.avg = class_income.df_raw["Inntekt"].mean()

# Print out results
print(f"The mode is {class_income.mode}")
print(f"The median is {class_income.median}")
print(f"The mean is {class_income.avg}")














####    Task 8    ####
###   Import data   ###
# Laban
laban = data_set()
laban.path = "oblig_1a/data/Laban42.csv"
laban.df_raw = pd.read_csv(laban.path)

# Brynhild
brynhild = data_set()
brynhild.path = "oblig_1a/data/Brynhild42.csv"
brynhild.df_raw = pd.read_csv(brynhild.path)



###   Find mode, median, mean, standard deviation and population standard deviation   ###
# Mode
laban.mode = laban.df_raw["Midpunkt"].mode().iloc[0]
brynhild.mode = brynhild.df_raw["Midpunkt"].mode().iloc[0]
print("Mode:")
print(brynhild.mode)

# Median
laban.median = laban.df_raw["Midpunkt"].median()
brynhild.median = brynhild.df_raw["Midpunkt"].median()
print("Median:")
print(brynhild.median)

# Mean
laban.avg = laban.df_raw["Midpunkt"].mean()
brynhild.avg = brynhild.df_raw["Midpunkt"].mean()
print("Avg:")
print(brynhild.avg)

# Standard deviation
laban.std = laban.df_raw["Midpunkt"].std()
brynhild.std = brynhild.df_raw["Midpunkt"].std()
print("Standard deviation:")
print(brynhild.std)

# Population standard deviation
laban.std_pop = laban.df_raw["Midpunkt"].std(ddof=0)
brynhild.std_pop = brynhild.df_raw["Midpunkt"].std(ddof=0)
print("Population standard deviation:")
print(brynhild.std_pop)



###   Tables   ###
## Laban
# Create a frequency table for the "Midpunkt" column
laban.freq = laban.df_raw['Midpunkt'].value_counts()

# Create cumulative frequency table for "Midpunkt" colum
laban.cum_freq = laban.df_raw['Midpunkt'].value_counts().sort_index(ascending=False).cumsum()

# Set table up in correct format
laban_sorted = laban.df_raw.groupby(['Lower', 'Upper', 'Midpunkt', 'Bredde']).size().reset_index(name='Antall')

# Sort the DataFrame by 'Frequency' in ascending order
laban_sorted = laban_sorted.sort_values('Midpunkt', ascending=False)

# Add a cumulative frequency column
laban_sorted['Kumulativt Antall'] = laban_sorted['Antall'].cumsum()


## Brynhild
# Create a frequency table for the "Midpunkt" column
brynhild.freq = brynhild.df_raw['Midpunkt'].value_counts()

# Create cumulative frequency table for "Midpunkt" colum
brynhild.cum_freq = brynhild.df_raw['Midpunkt'].value_counts().sort_index(ascending=False).cumsum()

# Set table up in correct format
brynhild_sorted = brynhild.df_raw.groupby(['Lower', 'Upper', 'Midpunkt', 'Bredde']).size().reset_index(name='Antall')

# Sort the DataFrame by 'Antall' in ascending order
brynhild_sorted = brynhild_sorted.sort_values('Midpunkt', ascending=False)

# Add a cumulative frequency column
brynhild_sorted['Kumulativt Antall'] = brynhild_sorted['Antall'].cumsum()




###   Plotting   ###
## Set-Up  ##
# Create the first figure for frequency diagrams
fig1, axs1 = plt.subplots(2, 1, figsize=(8.27, 11.69))

# LABAN
# First subplot: Frequency Diagram - Laban
axs1[0].bar(laban.freq.index, laban.freq, color='skyblue', width=4.5)
axs1[0].set_title('Frequency Diagram - Laban')
axs1[0].set_xlabel('Stretch before failure [mm]')
axs1[0].set_ylabel('Frequency')

# First subplot: Frequency Diagram - Laban
mean_line = axs1[0].axvline(laban.avg, color='red', linestyle='dashed', linewidth=2)
median_line = axs1[0].axvline(laban.median, color='green', linestyle='dashed', linewidth=2)
mode_line = axs1[0].axvline(laban.mode, color='orange', linestyle='dashed', linewidth=2)
std_line = axs1[0].axvline(laban.avg + laban.std, color='purple', linestyle='dashed', linewidth=2)
std_neg_line = axs1[0].axvline(laban.avg - laban.std, color='purple', linestyle='dashed', linewidth=2)
std_pop_line = axs1[0].axvline(laban.avg + laban.std_pop, color='Pink', linestyle='dashed', linewidth=2)
std_pop_neg_line = axs1[0].axvline(laban.avg - laban.std_pop, color='Pink', linestyle='dashed', linewidth=2)


# Add a legend
axs1[0].legend([mean_line, median_line, mode_line, std_line, std_pop_line], ['Mean', 'Median', 'Mode', 'SD', 'PSD'], loc='upper right')

# Brynhild
# Second subplot: Frequency Diagram - Brynhild
axs1[1].bar(brynhild.freq.index, brynhild.freq, color='salmon', width=4.5)
axs1[1].set_title('Frequency Diagram - Brynhild')
axs1[1].set_xlabel('Stretch before failure [mm]')
axs1[1].set_ylabel('Frequency')

# First subplot: Frequency Diagram - Brynhild
mean_line = axs1[1].axvline(brynhild.avg, color='red', linestyle='dashed', linewidth=2)
median_line = axs1[1].axvline(brynhild.median, color='green', linestyle='dashed', linewidth=2)
mode_line = axs1[1].axvline(brynhild.mode, color='orange', linestyle='dashed', linewidth=2)
std_line = axs1[1].axvline(brynhild.avg + brynhild.std, color='purple', linestyle='dashed', linewidth=2)
std_neg_line = axs1[1].axvline(brynhild.avg - brynhild.std, color='purple', linestyle='dashed', linewidth=2)
std_pop_line = axs1[1].axvline(brynhild.avg + brynhild.std_pop, color='Pink', linestyle='dashed', linewidth=2)
std_pop_neg_line = axs1[1].axvline(brynhild.avg - brynhild.std_pop, color='Pink', linestyle='dashed', linewidth=2)

# Add a legend
axs1[1].legend([mean_line, median_line, mode_line, std_line, std_pop_line], ['Mean', 'Median', 'Mode', 'SD', 'PSD'], loc='upper right')

# Increase the vertical space between the subplots
plt.subplots_adjust(hspace=0.5)

# Create the second figure for cumulative frequency diagrams
fig2, axs2 = plt.subplots(2, 1, figsize=(8.27, 11.69))

# LABAN
# First subplot: Cumulative Frequency Diagram - Laban
axs2[0].plot(laban.cum_freq.index, laban.cum_freq, marker='o', color='skyblue')
axs2[0].set_title('Cumulative Frequency Diagram - Laban')
axs2[0].set_xlabel('Stretch before failure [mm]')
axs2[0].set_ylabel('Cumulative Frequency')

# Second subplot: Cumulative Frequency Diagram - Laban
mean_line = axs2[0].axvline(laban.avg, color='red', linestyle='dashed', linewidth=2)
median_line = axs2[0].axvline(laban.median, color='green', linestyle='dashed', linewidth=2)
mode_line = axs2[0].axvline(laban.mode, color='orange', linestyle='dashed', linewidth=2)
std_line = axs2[0].axvline(laban.avg + laban.std, color='purple', linestyle='dashed', linewidth=2)
std_neg_line = axs2[0].axvline(laban.avg - laban.std, color='purple', linestyle='dashed', linewidth=2)
std_pop_line = axs2[0].axvline(laban.avg + laban.std_pop, color='Pink', linestyle='dashed', linewidth=2)
std_pop_neg_line = axs2[0].axvline(laban.avg - laban.std_pop, color='Pink', linestyle='dashed', linewidth=2)

# Add a legend
axs2[0].legend([mean_line, median_line, mode_line, std_line, std_pop_line], ['Mean', 'Median', 'Mode', 'SD', 'PSD'], loc='upper right')

# Brynhild
# Second subplot: Cumulative Frequency Diagram - Brynhild
axs2[1].plot(brynhild.cum_freq.index, brynhild.cum_freq, marker='o', color='salmon')
axs2[1].set_title('Cumulative Frequency Diagram - Brynhild')
axs2[1].set_xlabel('Stretch before failure [mm]')
axs2[1].set_ylabel('Cumulative Frequency')

# Second subplot: Cumulative Frequency Diagram - Brynhild
mean_line = axs2[1].axvline(brynhild.avg, color='red', linestyle='dashed', linewidth=2)
median_line = axs2[1].axvline(brynhild.median, color='green', linestyle='dashed', linewidth=2)
mode_line = axs2[1].axvline(brynhild.mode, color='orange', linestyle='dashed', linewidth=2)
std_line = axs2[1].axvline(brynhild.avg + brynhild.std, color='purple', linestyle='dashed', linewidth=2)
std_neg_line = axs2[1].axvline(brynhild.avg - brynhild.std, color='purple', linestyle='dashed', linewidth=2)
std_pop_line = axs2[1].axvline(brynhild.avg + brynhild.std_pop, color='Pink', linestyle='dashed', linewidth=2)
std_pop_neg_line = axs2[1].axvline(brynhild.avg - brynhild.std_pop, color='Pink', linestyle='dashed', linewidth=2)

# Add a legend
axs2[1].legend([mean_line, median_line, mode_line, std_line, std_pop_line], ['Mean', 'Median', 'Mode', 'SD', 'PSD'], loc='upper right')

# Increase the vertical space between the subplots
plt.subplots_adjust(hspace=0.5)


# Show the plots
#plt.show()


#### Save Files  ####
##  Save figures  ##
# Define the relative directory where you want to save the files
directory = "oblig_1a/figures/"

# Create the directory if it doesn't exist
os.makedirs(directory, exist_ok=True)


# Define the name of the first file
filename1 = 'freq.pgf'

# Construct the full path to the first file
full_path1 = os.path.join(directory, filename1)

# Save the first figure to this location
fig1.savefig(full_path1)


# Define the name of the second file
filename2 = 'cum_freq.pgf'

# Construct the full path to the second file
full_path2 = os.path.join(directory, filename2)

# Save the second figure to this location
fig2.savefig(full_path2)





## Save tables ##
# Specify the directory
directory_table = "oblig_1a/tables/"




###   Export Tables to LaTeX   ###
## Laban
# Save table in latex format
filepath = directory_table + "laban_table"
with open(filepath, 'w') as f:
  f.write(laban_sorted.to_latex())


## Brynhild
# Save table in latex format
filepath = directory_table + "brynhild_table"
with open(filepath, 'w') as f:
  f.write(brynhild_sorted.to_latex())






















"""
# Frequency Table
filepath = directory_table + "laban_freq"
with open(filepath, 'w') as f:
  f.write(laban.freq.to_latex())




# Cumalative frequency table
filepath = directory_table + "laban_cum_freq"
with open(filepath, 'w') as f:
  f.write(laban.cum_freq.to_latex())


## Brynhild
# Frequency Table
filepath = directory_table + "brynhild_freq"
with open(filepath, 'w') as f:
  f.write(brynhild.freq.to_latex())

# Cumalative frequency table
filepath = directory_table + "brynhild_cum_freq"
with open(filepath, 'w') as f:
  f.write(brynhild.cum_freq.to_latex())


print(laban.freq.to_latex())

####    EXTRAS    ####
"""
sorted_df = laban.df_raw.groupby(['Lower', 'Upper', 'Midpunkt', 'Bredde']).size().reset_index(name='Antall')
"""
"""